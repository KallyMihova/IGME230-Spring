<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Colors!</title>
</head>
<body>
<?PHP
	 $colors = ["red","green","blue"];
   
   
	//echo "<pre>";
	//print_r($colors);
	//echo "</pre>";
    //echo"<ol></ol>"
    $number = count($colors)-2;
    foreach($colors as $key=>$value){
   	echo "<ol>$number. $value</ol>";
        $number++;
   }
	
?>
<?PHP
   $links = ["RIT"=>"http://www.rit.edu",
   	"RPI"=>"http://www.rpi.edu",
   	"MCC"=>"http://www.monroecc.edu"];
   
   
   // 3 - loop through arrays with longer version of foreach loop
   foreach($links as $key=>$value){
   	echo '<ul><a href="'.$value.'">'.$key.'</a></ul>';
   }
?>
</body>
</html>