<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Facts!</title>
    
    <style>
        body {background-color: powderblue;margin-left:auto;margin-right:auto;height: 600;width: 400;}
        h1   {color: blue;}
        p    {color:chocolate;}
        form {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        }
        input {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        }
    </style>
</head>
<body>
    <h1>Kally's Daily Facts!</h1>
<?PHP
     $d = date(l);
	 $facts = ["In the average lifetime, a person will walk the equivalent of 5 times around the equator.",
                 "The most common name in the world is Mohammed.",
                 "Karoke means \"empty orchestra\" in Japanese.",
                 "When you die your hair still grows for a couple of months.",
                 "There are two credit cards for every person in the United States.",
                 "It took Leo Tolstoy six years to write \"War & Peace\".",
                 "1 in 5,000 north Atlantic lobsters are born bright blue."
               ];
if($d == "Monday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[0]</p>";
}
    else if($d == "Tuesday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[1]</p>";;
}
    else if($d == "Wednesday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[2]</p>";;
}
    else if($d == "Thursday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[3]</p>";
}
    else if($d == "Friday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[4]</p>";
}    
    else if($d == "Saturday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[5]</p>";
}    
    else if($d == "Sunday")
{
echo "<h2>Today is $d. Here is the fact of the day: </h2>"."<p>$facts[6]</p>";
}
	
?>
</body>
</html>