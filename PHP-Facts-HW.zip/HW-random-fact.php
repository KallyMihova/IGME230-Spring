<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Facts!</title>
    
    <style>
        body {background-color: powderblue;margin-left:auto;margin-right:auto;height: 600;width: 400;}
        h1   {color: blue;}
        p    {color: red;}
        form {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        }
        input {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        }
    </style>
</head>
<body>
    <h1>Kally's Random Facts Page!</h1>
    <h2>Hi! My name is Kally</h2>
    <p>Here is a random fact for you!</p>
<?PHP
	 $facts = ["In the average lifetime, a person will walk the equivalent of 5 times around the equator.",
                "Cats sleep 16 to 18 hours per day.",
                 "The most common name in the world is Mohammed.",
                 "Karoke means \"empty orchestra\" in Japanese.",
                 "When you die your hair still grows for a couple of months.",
                 "There are two credit cards for every person in the United States.",
                 "The Neanderthal's brain was bigger than yours is.",
                 "It took Leo Tolstoy six years to write \"War & Peace\".",
                 "The pancreas produces Insulin.",
                 "1 in 5,000 north Atlantic lobsters are born bright blue."
               ];

echo $facts[mt_rand(0,count($facts)-1)];

	
?>
    <form action="HW-random-fact.php" method="post">
	<input type="submit" value="Get another Fact!">
</form>
</body>
</html>